#!/bin/bash

# for mutating a protein/peptide complex and then docking the peptide to generate a score file.

pose=$1 #Filename without the .pdb
chain=$2
seqpos=$3
aa=$4

unbound_path=${WORK}/alphafold_output/LgBiT/ranked_0.pdb
rosetta_scripts_bin=${TACC_ROSETTA_BIN}/rosetta_scripts.cxx11mpi.linuxiccrelease
rosetta_fpdock_bin=${TACC_ROSETTA_BIN}/FlexPepDocking.cxx11mpi.linuxiccrelease
rosetta_database=$ROSETTA_DATABASE

mutate () {
    $rosetta_scripts_bin -s ${pose}.pdb -parser:protocol point_mutant_scan.xml -parser:script_vars focused_res=$seqpos focused_chain=$chain target_aa=$aa -out:prefix ${chain}${seqpos}_${aa} -database $rosetta_database
}

dock () {
    #chain=$1
    #seqpos=$2
    #aa=$3
    pdb=${chain}${seqpos}_${aa}${pose}_0001.pdb
    # Do dock stuff here...
    $rosetta_fpdock_bin \
        -database $rosetta_database \
        -s $pdb \
        -ex1 -ex2aro \
        -use_input_sc \
        -nstruct 3 \
        -unboundrot $unbound_path \
        -out:file:score_only ${pdb}_dock.sc \
        -out:file:scorefile_format json \
        -flexPepDockingMinimizeOnly
    #should try toggling this. with -pep_refine
}

cleanup () {
    mutatepdb=${chain}${seqpos}_${aa}${pose}_0001.pdb
    mutatesc=${chain}${seqpos}_${aa}score.sc
    rm $mutatepdb $mutatesc
}

mutate && dock && cleanup
# && dock && cleanup

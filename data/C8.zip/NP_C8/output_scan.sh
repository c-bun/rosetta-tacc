#!/bin/bash

pose="parent" #Filename without the .pdb.
output='job.job' #Filename for output file.

#rm $output

for chain in A; do
    for seqpos in {136..158}; do
	    for aa in ALA ARG ASN ASP CYS GLU GLN GLY HIS ILE LEU LYS MET PHE PRO SER THR TRP TYR VAL; do
            echo bash mutate_and_dock.sh $pose $chain $seqpos $aa >> $output
	    done
    done
done


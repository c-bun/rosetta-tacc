#!/bin/bash

expected_jobs=$1

while true; do
    done_jobs=$(grep -c completed *.out)
    #((percent=${done_jobs} / ${expected_jobs} * 100))
    #percent=$("${done_jobs}/${expected_jobs}" | bc)
    #echo Percent done:
    percent=$(echo "scale=2 ; $done_jobs / $expected_jobs" | bc)
    echo Percent done: $percent %
    sleep 10
done

